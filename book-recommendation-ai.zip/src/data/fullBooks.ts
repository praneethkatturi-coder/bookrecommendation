export interface FullBookChapter {
  title: string;
  content: string;
}

export const FULL_BOOKS_CONTENT: { [bookId: string]: FullBookChapter[] } = {
  atomic_habits: [
    {
      title: "Introduction & Fundamentals: The Compounding Power of 1% Daily Changes",
      content: "It is so easy to overestimate the importance of one defining moment and underestimate the value of making small improvements on a daily basis. Too often, we convince ourselves that massive success requires massive action. Whether it is losing weight, building a business, writing a book, winning a championship, or achieving any other goal, we put pressure on ourselves to make some earth-shattering improvement that everyone will talk about.\n\nMeanwhile, improving by 1 percent isn't particularly notable—sometimes it isn't even noticeable—but it can be far more meaningful, especially in the long run. The difference this tiny improvement can make over time is astounding. Here is how the math works out: if you can get 1 percent better each day for one year, you will end up thirty-seven times better by the time you're done. Conversely, if you get 1 percent worse each day for one year, you will decline nearly down to zero. What starts as a small win or a minor setback accumulates into something much more.\n\nHabits are the compound interest of self-improvement. The same way that money multiplies through compound interest, the effects of your habits multiply as you repeat them. They seem to make little difference on any given day and yet the impact they deliver over the months and years can be enormous. It is only when looking back two, five, or perhaps ten years later that the value of good habits and the cost of bad ones becomes strikingly apparent."
    },
    {
      title: "Chapter 1: Why Systems Beat Goals & Identity Shifting",
      content: "If you want better results, then forget about setting goals. Focus on your system instead. What is the difference between goals and systems? Goals are about the results you want to achieve. Systems are about the processes that lead to those results. If you are a coach, your goal might be to win a championship. Your system is the way you recruit players, manage assistant coaches, and conduct practice. If you are an entrepreneur, your goal might be to build a million-dollar business. Your system is how you test product ideas, hire employees, and run marketing campaigns.\n\nNow for the interesting question: If you completely ignored your goals and focused only on your system, would you still succeed? Clear argues that you would. The only way to actually win is to get better every day. We do not rise to the level of our goals, we fall to the level of our systems.\n\nFurthermore, true behavior change is identity change. The first layer is changing your outcomes (e.g., losing weight). The second layer is changing your process (e.g., repeating a daily run). The third and deepest layer is changing your identity (your belief systems, worldview, and self-judgments). Many people begin the process of changing their habits by focusing on what they want to achieve. This leads us to outcome-based habits. The alternative is to build identity-based habits. With this approach, we start by focusing on who we wish to become. Every action you take is a vote for the type of person you want to be."
    },
    {
      title: "Chapter 2: The First and Second Laws (Make It Obvious & Attractive)",
      content: "The First Law of Behavior Change is to Make It Obvious. One of our greatest challenges is that we perform habits automatically without conscious attention. To build a new habit, you must call out the cues in your environment. You can use implementation intentions: 'I will [BEHAVIOR] at [TIME] in [LOCATION]'. For example, 'I will write 200 words of code at 8:00 AM in my home study'. Another powerful technique is habit stacking: 'After [CURRENT HABIT], I will [NEW HABIT]'. Additionally, redesign your environment to make the cue of your good habits highly visible. If you want to practice guitar more, put the guitar stand right in the middle of your living room.\n\nThe Second Law is to Make It Attractive. Habits are dopamine-driven loops. When dopamine rises, so does our motivation to act. We can use temptation bundling to make our habits more attractive by linking an action we need to do with an action we want to do. For instance, you can bundle studying with listening to your favorite ambient beats. Finally, join a culture where your desired behavior is the normal behavior. When you see others coding, writing, or reading daily, you naturally absorb their social cues and feel highly encouraged to maintain the cycle."
    },
    {
      title: "Chapter 3: The Third and Fourth Laws (Make It Easy & Satisfying)",
      content: "The Third Law is to Make It Easy. Human behavior naturally follows the Law of Least Effort. We gravitate toward options that require the least amount of work. Therefore, we must reduce the friction associated with good behaviors. To build a solid habit, prime your environment in advance. If you want to draw tomorrow morning, set up your sketchbook, pencil, and reference material on your desk tonight. Use the 2-Minute Rule: 'When you start a new habit, it should take less than two minutes to do.' A complex habit like 'Read 30 books per year' becomes 'Read one page'. Once you begin, continuing is much easier.\n\nThe Fourth Law is to Make It Satisfying. The first three laws increase the odds that a behavior will be performed this time. The fourth law increases the odds that it will be repeated next time. Cardinal Rule of Behavior Change: What is immediately rewarded is repeated. What is immediately punished is avoided. Because we have an immediate-return brain, we need small, immediate validations of success. Track your habits visually using a habit tracker, and protect your momentum by pledging: 'Never miss twice.' If you miss one day, double down the next day to prevent your systems from decaying."
    }
  ],
  deep_work: [
    {
      title: "Introduction: The Rare and Valuable Ability to Concentrate",
      content: "Deep work is the ability to focus without distraction on a cognitively demanding task. It is a skill that allows you to quickly master complicated information and produce better results in less time. Deep work will make you better at what you do and provide the sense of true fulfillment that comes from craftsmanship. In short, deep work is like a super power in our increasingly competitive twenty-first century economy.\n\nYet, most people have lost the ability to spend their days in deep focus. Instead, they spend their hours in a frantic blur of emails, social media, and slack threads, not realizing there is an enormous difference between high-value concentration and low-value logistics (Shallow Work). Shallow work includes non-cognitively demanding, logistical-style tasks, often performed while distracted. These efforts do not create much new value in the world and are incredibly easy to replicate.\n\nAs digital tools continue to fragment our attention, the market value of deep work is rising rapidly. Those who cultivate this skill will thrive, while those who drown in shallow interruptions will find their skills automated away or outsourced to cheaper labor."
    },
    {
      title: "Chapter 1: The Attention Residue Trap & Deep Work Philosophies",
      content: "When you switch from some Task A to another Task B, your attention does not follow immediately—a residue of your attention remains stuck thinking about the original task. This is especially true if Task A was unfinished or open-ended. Even if you check your email for just 30 seconds and return to writing your report, that micro-interruption leaves a computational penalty in your prefrontal cortex. This 'attention residue' significantly lowers your cognitive performance, making it nearly impossible to solve complex intellectual problems with maximum intelligence.\n\nTo schedule deep work successfully, you must select one of Newport's four distinct focus philosophies:\n\n1. Monastic Philosophy: Involves eliminating all shallow obligations and isolating yourself entirely for months at a time.\n2. Bimodal Philosophy: Divides your time into multi-day blocks of pure isolation, then returns to normal logistical duties.\n3. Rhythmic Philosophy: Establishes a predictable, daily routine of 90-minute to 3-hour focus blocks (most practical for busy professionals).\n4. Journalistic Philosophy: Prompts you to drop into deep focus on a moment's notice whenever a free window of time appears (requires advanced training)."
    },
    {
      title: "Chapter 2: Master Boredom & Reclaim Your Prefrontal Cortex",
      content: "To build a deep work habit, you must train your brain. If you are constantly satisfying even the slightest hint of boredom with a quick scroll on your phone, you train your brain to have a permanent addiction to distraction. Just like an athlete must train their body, an intellectual must train their attention. Practice boredom. Let your mind sit in quiet reflection during a commute or while waiting in line at a grocery store.\n\nQuit social media if it does not offer clear, irreplaceable value to your life. The primary argument of social media companies is that missing out on minor updates is a tragedy. However, the cost of fragmented focus is much higher. Run a 30-day self-experiment: shut down your accounts without telling anyone. After 30 days, ask yourself: Will my life be significantly better if I reactivate them? Usually, the answer is no."
    },
    {
      title: "Chapter 3: Execute with Extreme Discipline",
      content: "Deep work requires strict execution guidelines. Newport recommends four disciplines of execution:\n\n1. Focus on the Wildly Important: Establish a highly specific, high-stakes intellectual goal (e.g., writing a breakthrough paper or learning a complex language framework).\n2. Act on Lead Measures: Track the metrics you control directly (e.g., the number of hours spent in deep undistracted concentration daily) rather than lag measures (e.g., papers published).\n3. Keep a Compelling Scoreboard: Visually mark down your deep-focus hours in a physical spreadsheet or calendar to maintain motivation.\n4. Create a Cadence of Accountability: Review your progress weekly to adjust your schedule and optimize your focus setups."
    }
  ],
  psychology_of_money: [
    {
      title: "Introduction: Financial Behavior Matters More Than Math",
      content: "Doing well with money has surprisingly little to do with how smart you are, and a great deal to do with how you behave. And behavior is hard to teach, even to really smart people. A genius who loses control of their emotions can be a financial disaster. Conversely, ordinary folks with no financial education can be wealthy if they have a handful of behavioral skills that have nothing to do with formal intelligence measures.\n\nWe tend to think about money as a math-based field, where you input data into formulas and follow strict rules of capital allocation. But in the real world, people don't make financial decisions on spreadsheets. They make them at the dinner table, under the influence of pride, ego, marketing, and fear. To understand wealth, we must study history, human psychology, and our own natural cognitive traps."
    },
    {
      title: "Chapter 1: The Silent Dividend of Time Sovereignty",
      content: "The highest dividend money pays is control over your time. Being able to do what you want, when you want, with whom you want, for as long as you want, is the absolute peak of financial freedom. This time sovereignty provides a reliable, permanent stream of life happiness that is far superior to any physical luxury item or massive mansion.\n\nWhen we buy expensive items, we think we are buying respect and admiration from others. In reality, other people don't look at you with respect. They look at your car or watch and imagine themselves possessing it. This is 'The Man in the Car Paradox.' No one is impressed by your luxury purchases as much as you are. Control your ego, live below your means, and use your excess capital to secure your personal autonomy."
    },
    {
      title: "Chapter 2: Compounding vs. Interruption and the Cash Buffer",
      content: "The secret to financial success is simple: compounding. But compounding only works if you let it grow undisturbed for decades. The most valuable investment quality is not picking the highest-performing stock, but staying in the game long enough to let compounding work its magic.\n\nIn order to secure survival over economic downturns, you must build room for error into your financial architecture. A high cash buffer is not inefficient; indeed, it is the insurance premium that ensures you will never be forced to sell your stocks during a market panic. It protects your capital from being liquidated at the worst possible moment. True financial planning means planning for your plan to not go according to plan."
    }
  ],
  thinking_fast_slow: [
    {
      title: "Introduction: Meet System 1 and System 2",
      content: "Psychologist Daniel Kahneman outlines the dual-process model of the human brain, dividing human thought into two distinct operating engines:\n\nSystem 1 is fast, automatic, emotional, sub-conscious, and energy-efficient. It operates instantly to detect patterns, read faces, and jump away from danger. It is our evolutionary survival mechanism, running constantly behind the scenes.\n\nSystem 2 is slow, logical, effortful, and lazy. It handles complex equations, reads small text, and manages hard strategic choices. It requires deliberate focus and burns high levels of glucose. Because our brain is highly optimized to save energy, it defaults to System 1 shortcuts whenever possible, leading to systematic, universal cognitive errors."
    },
    {
      title: "Chapter 1: The Fallacy of Cognitive Ease & WYSIATI",
      content: "When our brain operates with 'Cognitive Ease,' things feel familiar, safe, and true. This makes us highly vulnerable to confirmation bias and repetitive lies. System 1 constructs a flowing, coherent story using only the immediate clues in its environment. Kahneman labels this biological bias as WYSIATI: 'What You See Is All There Is.' We fail to account for missing statistical facts, building high-conviction opinions on low-quality evidence."
    },
    {
      title: "Chapter 2: Anchoring, Availability & Loss Aversion",
      content: "We estimate values using irrelevant suggestions (Anchoring) and judge the frequency of events by how easily we can recall dramatic examples (Availability). Under Prospect Theory, Kahneman demonstrates that the psychological pain of losing $100 is roughly twice as strong as the joy of winning $100. This loss aversion causes people to stick with failing projects, reject lucrative bets, and make irrational financial corrections."
    }
  ],
  lean_startup: [
    {
      title: "Introduction: Extreme Uncertainty and the Lean Mission",
      content: "A startup is a human institution designed to create a new product or service under conditions of extreme uncertainty. Traditional management practices, built on predictable forecasts and rigid product specs, do not work in this environment. To build a successful company, we must apply scientific management, treating our business model as a set of hypotheses waiting to be validated."
    },
    {
      title: "Chapter 1: The Build-Measure-Learn Loop",
      content: "The core engine of startup progress is the Build-Measure-Learn feedback loop. First, we form a hypothesis. Second, we build a Minimum Viable Product (MVP) to gather real customer data. Third, we measure customer habits using actionable metrics (e.g. cohort retention). Fourth, we learn whether our hypothesis was correct, deciding to pivot or persevere."
    },
    {
      title: "Chapter 2: Actionable Metrics vs. Vanity Metrics",
      content: "Vanity metrics make you feel good (e.g. total page views, cumulative registrations) but do not reveal actual value or user habits. Actionable metrics are clear, repeatable data points that guide strategic decisions. Focus on cohort analysis, customer lifetime value, and daily active engagement to verify your startup engine is growing."
    }
  ],
  zero_to_one: [
    {
      title: "Introduction: Globalization vs. Technology",
      content: "Every project in business starts only once. Going from '1 to n' is globalization: copying things that already work to other markets. Going from '0 to 1' is technology: creating entirely new value that did not exist before. True progress stems from bold technology developers who invent unique solutions to underserved human problems."
    },
    {
      title: "Chapter 1: The Power of Creative Monopolies",
      content: "Perfect competition eats up all profits, leaving zero capital for research and growth. Monopolies, however, generate high profit margins that fund long-term development. A creative monopoly means producing a product so superior that no other company can compete. To build a monopoly, start with a tiny niche market, dominate it, and expand outward."
    },
    {
      title: "Chapter 2: The Monopolist Checklist",
      content: "A lasting, high-value monopoly requires four core structures:\n\n1. Proprietary Technology: Must be at least 10x better than the closest substitute.\n2. Network Effects: Your product becomes more valuable as more people use it.\n3. Economies of Scale: Unit costs decline as sales volume increases.\n4. Strong Brand Equity: Uncopyable identity and polished UI aesthetics."
    }
  ],
  meditations: [
    {
      title: "Introduction: The Inner Citadel of the Soul",
      content: "The Roman Emperor Marcus Aurelius wrote Meditations as a personal journal of Stoic reflections. Stoicism teaches that the external universe is completely neutral. It is not external events that cause us suffering, but our judgment of them. If we clear away our anger, we can secure peace within our inner citadel."
    },
    {
      title: "Chapter 1: Control Your Reactivity and Embrace Duty",
      content: "Control what you can control: your thoughts, intentions, and reactions. Let go of what you cannot control: other people's behavior, luck, and nature. Prepare yourself every morning to encounter difficult, annoying individuals, remembering they act out of ignorance, not malice. Complete your civic duty with patience and integrity."
    },
    {
      title: "Chapter 2: The Obstacle is the Way & Memento Mori",
      content: "Every challenge is an opportunity to practice virtue: patience, courage, and logic. Marcus writes: 'The impediment to action advances action. What stands in the way becomes the way.' Live everyday in the perspective of your inevitable mortality, stripping away false pride and focusing on serving humanity."
    }
  ],
  mindset: [
    {
      title: "Introduction: Fixed Mindset vs. Growth Mindset",
      content: "Psychologist Carol Dweck outlines how a simple belief about your biology alters your entire career and personal happiness. A Fixed Mindset assumes talents and intelligence are unchangeable birth cards. A Growth Mindset believes skills are muscles carved through effort, practice, and learning."
    },
    {
      title: "Chapter 1: Confront Traps and Embrace the Power of Yet",
      content: "People with fixed mindsets see mistakes as threats to their identity, leading them to hide flaws and avoid difficult trials. When facing any difficult concept, add the word 'Yet': 'I don't understand this, yet.' Reframing struggle as progress stimulates neural connections and unlocks elite capabilities."
    },
    {
      title: "Chapter 2: Cultivating Growth in Teams and Careers",
      content: "In corporations and relationships, a fixed mindset creates high ego tension and defensiveness. Leaders must reward input processes, deliberate effort, and learning trajectories rather than natural brilliance. Welcome feedback as vital guidance rather than personal attacks."
    }
  ],
  grit: [
    {
      title: "Introduction: The Grit Predictor",
      content: "Angela Duckworth argues that our obsession with natural talent is a form of self-defense: if genius is a born gift, we do not have to compete. However, scientific research shows that Grit—the combination of long-term passion and matching daily perseverance—is the strongest predictor of high-stakes success."
    },
    {
      title: "Chapter 1: The Effort Multiplier",
      content: "Duckworth represents achievement through two simple equations: Talent multiplied by Effort equals Skill, and Skill multiplied by Effort equals Achievement. Effort counts twice. Without effort, your talent is just unfulfilled potential, and your skills are non-productive assets."
    },
    {
      title: "Chapter 2: The Four Pillars of Grit",
      content: "You can grow grit from the inside out:\n\n1. Interest: Find topics that stir your intellectual curiosity.\n2. Practice: Engage in daily deliberate practice to patch weaknesses.\n3. Purpose: Connect your work to a larger contribution for humanity.\n4. Hope: Maintain active optimism that your inputs shape your trajectory."
    }
  ],
  indistractable: [
    {
      title: "Introduction: The True Root of Distraction",
      content: "Distraction is not a technology problem; it is an emotional coping mechanism designed to escape discomfort, loneliness, uncertainty, or stress. Technology acts as a convenient painkiller. To beat distraction, we must identify internal emotional triggers and practice sitting with cravings."
    },
    {
      title: "Chapter 1: Timebox Your Week for Traction",
      content: "The opposite of distraction is Traction: actions that pull you closer to your scheduled values. You cannot call something a distraction unless you know what it distracted you from. Schedule your week entirely in advance, setting blocks for sleep, training, relationships, and deep study."
    },
    {
      title: "Chapter 2: Hacks, Friction, and Pacts",
      content: "Control external cues. Clean your desktop, disable non-essential banner notifications, and remove distracting phone apps. Establish pre-commitment contracts (Effort pacts, Price pacts, or Identity pacts like 'I am indistractable') to keep your focus locked in."
    }
  ]
};
