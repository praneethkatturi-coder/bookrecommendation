import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Square, Volume2, FastForward, Headphones, Sparkles, AlertCircle } from 'lucide-react';
import { Book } from '../types';
import { FULL_BOOKS_CONTENT } from '../data/fullBooks';

interface AudioPlayerProps {
  book: Book;
  onFinishedReading?: () => void;
}

export default function AudioPlayer({ book, onFinishedReading }: AudioPlayerProps) {
  const [audioMode, setAudioMode] = useState<'intro' | 'summary' | 'full'>('summary');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(0); // 0 to 100
  const [currentTime, setCurrentTime] = useState(0); // in seconds
  const [playbackRate, setPlaybackRate] = useState(1); // 0.75, 1, 1.25, 1.5, 2
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceName, setSelectedVoiceName] = useState<string>('');
  const [speechSupported, setSpeechSupported] = useState(true);
  const [activeSentenceIndex, setActiveSentenceIndex] = useState(0);

  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const timerRef = useRef<number | null>(null);

  // Dynamically compile the script for natural narration based on current mode
  const getActiveScript = (): string => {
    if (audioMode === 'intro') {
      return book.audioScript;
    }

    if (audioMode === 'summary') {
      let text = `Welcome to the complete highlights digest of ${book.title} by ${book.author}.\n\n`;
      text += `Focus Objective: ${book.overallAim}\n\n`;
      
      text += `First, let us go through the core one-minute milestones.\n`;
      book.summary1Min.forEach((bullet, idx) => {
        text += `Point number ${idx + 1}: ${bullet}\n`;
      });

      text += `\nNow, let us examine the detailed executive chapter summary.\n`;
      book.summary5Min.forEach((ch, idx) => {
        text += `Detail ${idx + 1}: ${ch.chapter}. ${ch.text}\n`;
        text += `The design action takeaway is as follows: ${ch.takeaway}.\n\n`;
      });

      text += `Let us review the core lessons and actionable takeaways.\n`;
      book.insights.forEach((insight, idx) => {
        text += `Action point number ${idx + 1}: ${insight}\n`;
      });

      text += `\nIn conclusion, we evaluate your ultimate target outcome: ${book.outcome}\n\n`;
      text += `You have completed the highlights digest of ${book.title}. Continuous learning systems shape incredible growth trajectories.`;
      return text;
    }

    // Complete Audio Book Unabridged Mode (using FULL_BOOKS_CONTENT)
    const fullChapters = FULL_BOOKS_CONTENT[book.id];
    if (fullChapters && fullChapters.length > 0) {
      let text = `Welcome to the premium complete audio edition of ${book.title} by ${book.author}.\n\n`;
      fullChapters.forEach((ch, idx) => {
        text += `Chapter ${idx + 1}: ${ch.title}.\n\n${ch.content}\n\n`;
      });
      text += `You have fully completed the unabridged audio version of ${book.title}. Continuous learning systems shape incredible growth trajectories. Thank you for listening.`;
      return text;
    }

    return book.audioScript;
  };

  const activeScript = getActiveScript();

  // Split script into clean, small sentences for interactive display
  const sentences = activeScript
    .split(/(?<=[.!?\n])\s+/)
    .map(s => s.trim())
    .filter(s => s.length > 0);

  // estimate total seconds (Speech synthesis standard is ~135 WPM)
  const getEstimatedSeconds = (): number => {
    const wordCount = activeScript.trim().split(/\s+/).length;
    return Math.max(45, Math.ceil((wordCount / 135) * 60));
  };

  const durationSeconds = getEstimatedSeconds();

  // Reload voices on mount and voice changes
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      setSpeechSupported(true);
      const updateVoices = () => {
        const availableVoices = window.speechSynthesis.getVoices();
        const englishVoices = availableVoices.filter(v => v.lang.toLowerCase().includes('en'));
        setVoices(englishVoices.length > 0 ? englishVoices : availableVoices);
        
        if (englishVoices.length > 0) {
          const defaultVoice = englishVoices.find(v => v.name.includes('Google') || v.name.includes('Natural')) || englishVoices[0];
          setSelectedVoiceName(defaultVoice.name);
        } else if (availableVoices.length > 0) {
          setSelectedVoiceName(availableVoices[0].name);
        }
      };

      updateVoices();
      window.speechSynthesis.onvoiceschanged = updateVoices;
    } else {
      setSpeechSupported(false);
    }

    return () => {
      stopSpeech();
    };
  }, [book.id]);

  // Clean stop when book or audioMode changes
  useEffect(() => {
    stopSpeech();
  }, [book.id, audioMode]);

  // Handle active countdown timer logic
  useEffect(() => {
    if (isPlaying && !isPaused) {
      timerRef.current = window.setInterval(() => {
        setCurrentTime(prevTime => {
          const nextTime = prevTime + 0.1 * playbackRate;
          if (nextTime >= durationSeconds) {
            handleSpeechEnd();
            return durationSeconds;
          }
          
          const progressPercent = nextTime / durationSeconds;
          const sentenceCount = sentences.length;
          const currentSentenceIdx = Math.min(
            Math.floor(progressPercent * sentenceCount),
            sentenceCount - 1
          );
          setActiveSentenceIndex(currentSentenceIdx);
          setProgress(progressPercent * 100);
          
          return nextTime;
        });
      }, 100);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, isPaused, playbackRate, durationSeconds, sentences.length]);

  const startSpeech = (fromSentenceIdx: number = 0) => {
    if (!speechSupported) return;

    window.speechSynthesis.cancel();

    const textToSpeak = sentences.slice(fromSentenceIdx).join(' ');
    if (!textToSpeak.trim()) return;

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    
    if (selectedVoiceName) {
      const voiceObj = voices.find(v => v.name === selectedVoiceName);
      if (voiceObj) {
        utterance.voice = voiceObj;
      }
    }

    utterance.rate = playbackRate * 0.95; 
    utterance.pitch = 1.0;

    utterance.onboundary = (event) => {
      if (event.name === 'word') {
        const charIndex = event.charIndex;
        const totalChars = textToSpeak.length;
        const textPercent = charIndex / totalChars;
        
        const remainingSentencesCount = sentences.length - fromSentenceIdx;
        const offset = Math.min(
          Math.floor(textPercent * remainingSentencesCount),
          remainingSentencesCount - 1
        );
        setActiveSentenceIndex(fromSentenceIdx + offset);
      }
    };

    utterance.onend = () => {
      handleSpeechEnd();
    };

    utterance.onerror = (e) => {
      console.log('Speech error:', e);
      if (e.error !== 'interrupted') {
        setIsPlaying(false);
      }
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseSpeech = () => {
    if (!speechSupported) return;
    window.speechSynthesis.pause();
    setIsPaused(true);
  };

  const resumeSpeech = () => {
    if (!speechSupported) return;
    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
      startSpeech(activeSentenceIndex);
    }
  };

  const stopSpeech = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (speechSupported) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(false);
    setIsPaused(false);
    setProgress(0);
    setCurrentTime(0);
    setActiveSentenceIndex(0);
  };

  const handleSpeechEnd = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsPlaying(false);
    setIsPaused(false);
    setProgress(100);
    setCurrentTime(durationSeconds);
    setActiveSentenceIndex(sentences.length - 1);
    if (onFinishedReading) {
      onFinishedReading();
    }
  };

  const changeRate = (newRate: number) => {
    setPlaybackRate(newRate);
    if (isPlaying) {
      const savedTimeRatio = progress / 100;
      startSpeech(activeSentenceIndex);
      const targetTime = savedTimeRatio * durationSeconds;
      setCurrentTime(targetTime);
      setProgress(savedTimeRatio * 100);
    }
  };

  const formatSeconds = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = Math.floor(totalSec % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-xl border border-slate-800 space-y-4">
      {/* Header section with Toggles */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2 border-b border-slate-800/60">
        <div className="flex items-center gap-2 text-indigo-400 font-mono text-xs uppercase tracking-wider">
          <Headphones size={15} />
          <span>AI Audio Book summary</span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-400">
          <Sparkles size={13} className="text-amber-450 text-amber-400 animate-pulse" />
          <span>Dynamic Reading Mode Generator</span>
        </div>
      </div>

      {/* Length selector tabs */}
      <div className="bg-slate-950 p-1 rounded-xl flex gap-1 border border-slate-800 text-xs">
        <button
          onClick={() => {
            setAudioMode('intro');
          }}
          className={`flex-1 py-2 rounded-lg text-center font-bold tracking-tight transition cursor-pointer ${
            audioMode === 'intro'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-250 hover:bg-slate-900/40'
          }`}
          title="Introductory Direct Teaser (~2m)"
        >
          ⏱ Teaser (~2m)
        </button>
        <button
          onClick={() => {
            setAudioMode('summary');
          }}
          className={`flex-1 py-2 rounded-lg text-center font-bold tracking-tight transition cursor-pointer ${
            audioMode === 'summary'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-250 hover:bg-slate-900/40'
          }`}
          title="Comprehensive Highlight Summary (~5m)"
        >
          📚 Summary (~5m)
        </button>
        <button
          onClick={() => {
            setAudioMode('full');
          }}
          className={`flex-1 py-2 rounded-lg text-center font-bold tracking-tight transition cursor-pointer flex items-center justify-center gap-1 ${
            audioMode === 'full'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-250 hover:bg-slate-900/40'
          }`}
          title="Complete Audio Book Narration (~15m)"
        >
          <span>📖 Full Book (~15m)</span>
          <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[8px] px-1 py-0.5 rounded uppercase font-black shrink-0">
            Full
          </span>
        </button>
      </div>

      {speechSupported ? (
        <div className="space-y-4">
          {/* Cover Placeholder & Dynamic Audio Wave */}
          <div className="flex items-center gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800/60">
            <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${book.coverGradient} flex items-center justify-center font-bold text-sm text-white shrink-0 shadow-md`}>
              {book.title.slice(0, 2).toUpperCase()}
            </div>
            <div className="flex-1 overflow-hidden">
              <h4 className="font-semibold text-sm text-slate-150 truncate leading-snug">{book.title}</h4>
              <p className="text-xs text-slate-400 truncate">{book.author}</p>
            </div>
            
            {/* Pulsing Visual Waveform */}
            <div className="flex items-end justify-center gap-0.5 h-6 w-12 px-1">
              {[0.4, 0.9, 0.5, 0.75, 0.3, 0.8].map((val, i) => (
                <div
                  key={i}
                  className="w-1 bg-gradient-to-t from-indigo-500 to-sky-400 rounded-full transition-all duration-300"
                  style={{
                    height: isPlaying && !isPaused ? `${val * 100}%` : '15%',
                    animation: isPlaying && !isPaused ? `pulse 1.2s infinite ease-in-out` : 'none',
                    animationDelay: `${i * 0.15}s`
                  }}
                />
              ))}
            </div>
          </div>

          {/* Scrolling Interactive Transcript */}
          <div className="h-32 overflow-y-auto bg-slate-950 p-4 rounded-xl text-xs border border-slate-800/80 leading-relaxed scroll-smooth text-slate-300">
            {sentences.map((sentence, idx) => {
              const isActive = idx === activeSentenceIndex && isPlaying;
              return (
                <span
                  key={idx}
                  className={`transition-all duration-300 inline mr-2 px-1 py-0.5 rounded cursor-pointer ${
                    isActive 
                      ? 'bg-indigo-900/80 text-white font-semibold border-l-2 border-indigo-400 shadow-sm shadow-indigo-950 inline-block scale-[1.01]' 
                      : idx < activeSentenceIndex && isPlaying
                        ? 'text-slate-500 decoration-slate-600 opacity-60'
                        : 'text-slate-400 hover:text-slate-200'
                  }`}
                  onClick={() => {
                    const ratio = idx / sentences.length;
                    const targetTime = ratio * durationSeconds;
                    setProgress(ratio * 100);
                    setCurrentTime(targetTime);
                    setActiveSentenceIndex(idx);
                    startSpeech(idx);
                  }}
                >
                  {sentence}
                </span>
              );
            })}
          </div>

          {/* Timeline slider */}
          <div>
            <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-1">
              <span>{formatSeconds(currentTime)}</span>
              <span>{formatSeconds(durationSeconds)}</span>
            </div>
            <div className="relative group cursor-pointer">
              <input
                type="range"
                min="0"
                max="100"
                step="0.1"
                value={progress}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  setProgress(val);
                  const targetTime = (val / 100) * durationSeconds;
                  setCurrentTime(targetTime);
                  
                  const activeIdx = Math.min(
                    Math.floor((val / 100) * sentences.length),
                    sentences.length - 1
                  );
                  setActiveSentenceIndex(activeIdx);
                  if (isPlaying) {
                    startSpeech(activeIdx);
                  }
                }}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 group-hover:bg-slate-700 transition animate-fade-in"
              />
            </div>
          </div>

          {/* Action Panel: Play, speed, voice */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
            {/* Control Buttons */}
            <div className="flex items-center justify-center sm:justify-start gap-3">
              {isPlaying && !isPaused ? (
                <button
                  onClick={pauseSpeech}
                  className="w-10 h-10 rounded-full bg-slate-800 hover:bg-slate-700 hover:scale-105 active:scale-95 transition flex items-center justify-center shadow-md cursor-pointer"
                  title="Pause Summary"
                >
                  <Pause size={16} className="text-slate-200 fill-slate-200" />
                </button>
              ) : (
                <button
                  onClick={resumeSpeech}
                  className="w-10 h-10 rounded-full bg-indigo-600 hover:bg-indigo-500 hover:scale-105 active:scale-95 transition flex items-center justify-center shadow-lg shadow-indigo-950/40 cursor-pointer"
                  title="Play Summary Out Loud"
                >
                  <Play size={16} className="translate-x-0.5 text-white fill-white" />
                </button>
              )}

              {(isPlaying || isPaused) && (
                <button
                  onClick={stopSpeech}
                  className="w-8 h-8 rounded-full bg-slate-800 hover:bg-red-950/40 hover:text-red-400 hover:scale-105 active:scale-95 transition flex items-center justify-center cursor-pointer"
                  title="Restart / Stop"
                >
                  <Square size={11} className="text-slate-300 fill-current" />
                </button>
              )}
            </div>

            {/* Speeds and Voice selections */}
            <div className="flex flex-wrap items-center justify-center gap-3">
              {/* Playback speed selector */}
              <div className="flex bg-slate-950 border border-slate-800 p-0.5 rounded-lg text-[11px] font-mono">
                {[0.75, 1, 1.25, 1.5, 2].map(speed => (
                  <button
                    key={speed}
                    onClick={() => changeRate(speed)}
                    className={`px-1.5 py-1 rounded transition cursor-pointer ${
                      playbackRate === speed
                        ? 'bg-indigo-600 text-white font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>

              {/* Voice selector */}
              {voices.length > 0 && (
                <select
                  value={selectedVoiceName}
                  onChange={(e) => {
                    setSelectedVoiceName(e.target.value);
                    if (isPlaying) {
                      setTimeout(() => startSpeech(activeSentenceIndex), 100);
                    }
                  }}
                  className="bg-slate-950 border border-slate-800 rounded-lg text-[11px] py-1.5 px-2 max-w-[130px] text-slate-300 hover:text-slate-200 cursor-pointer focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {voices.map(voice => (
                    <option key={voice.name} value={voice.name}>
                      {voice.name.replace(/Microsoft|Google|Apple/g, '').trim()} ({voice.lang.split('-')[0].toUpperCase()})
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="p-4 bg-amber-950/20 text-amber-300 border border-amber-900/50 rounded-xl flex gap-3 text-xs">
          <AlertCircle size={20} className="shrink-0 text-amber-400" />
          <div>
            <p className="font-semibold mb-1">Web Speech Synthesis Unsupported</p>
            <p className="opacity-80 leading-normal">Your browser does not support full TTS audio. We will simulate the playback timeline on screen, but audio will remain disabled.</p>
          </div>
        </div>
      )}
    </div>
  );
}
